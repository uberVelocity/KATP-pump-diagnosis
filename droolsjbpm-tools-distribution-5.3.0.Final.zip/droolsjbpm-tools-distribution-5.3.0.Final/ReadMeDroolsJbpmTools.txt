Welcome to Drools and jBPM tools
================================

Introduction
------------

Drools Eclipse bundles the drools plugins for eclipse.
This zip is useful if you don't want to or can't use the online update site.

Installing the plugins in Eclipse
---------------------------------

- Open Eclipse.
- Open the menu "Help", menu item "Install new software..."
- Click on the button "Add..." to add a new software site.
- Fill in the name "drools local update site"
- Click on the button "Local..." and select ".../binaries/org.drools.updatesite"
- Select all the plugins. Click the buttons "Next" and "Finish".

Sources
-------

The source jars are in the sources directory.

But to build from sources, pull the sources with git:
  https://github.com/droolsjbpm
and follow these instructions:
  https://github.com/droolsjbpm/droolsjbpm-build-bootstrap/blob/master/README.md
